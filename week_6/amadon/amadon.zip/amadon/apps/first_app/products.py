items = [
    {
        "id": 1,
        "name": "Raspberry Pi",
        "price": 35,
    },
    {
        "id": 2,
        "name": "Nintendo Switch",
        "price": 350,
    },
    {
        "id": 3,
        "name": "Legend of Zelda",
        "price": 60,
    },
    {
        "id": 4,
        "name": "Screen and button PCB set",
        "price": 55,
    },
]